import os
import subprocess
from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
import wave
from vosk import Model, KaldiRecognizer
import json
import requests
import time

app = Flask(__name__)

# Ensure upload directory exists
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Set up the path to FFmpeg
FFMPEG_PATH = r'Directory\bin\ffmpeg.exe'

# Path to the Vosk model
VOSK_MODEL_PATH = r'models/vosk-model-en-us-0.22'

# Function to extract audio from video using FFmpeg
def extract_audio(video_path, output_audio_path):
    if not os.path.exists(video_path):
        print(f"Error: Video file {video_path} not found.")
        return None
    try:
        command = [
            FFMPEG_PATH,
            '-i', video_path,
            '-vn', '-acodec', 'pcm_s16le', '-ar', '16000', '-ac', '1', output_audio_path
        ]
        subprocess.run(command, check=True, stderr=subprocess.PIPE)
        return output_audio_path
    except subprocess.CalledProcessError as e:
        print(f"Error extracting audio: {e.stderr.decode('utf-8')}")
        return None

# Function to transcribe the audio with Vosk
def transcribe_audio_with_vosk(audio_path):
    if not os.path.exists(audio_path):
        return "Error: Audio file not found."
    
    try:
        wf = wave.open(audio_path, "rb")
        model = Model(VOSK_MODEL_PATH)
        recognizer = KaldiRecognizer(model, wf.getframerate())

        full_transcription = []
        while True:
            data = wf.readframes(4000)
            if len(data) == 0:
                break
            if recognizer.AcceptWaveform(data):
                result_json = json.loads(recognizer.Result())
                if 'text' in result_json:
                    full_transcription.append(result_json['text'])

        final_result = json.loads(recognizer.FinalResult())
        if 'text' in final_result:
            full_transcription.append(final_result['text'])

        return "\n".join(full_transcription)
    
    except wave.Error as e:
        print(f"Error reading wave file: {e}")
        return "Error reading wave file."
    except Exception as e:
        print(f"Error during transcription: {e}")
        return "Error during transcription."

# Function to summarize the transcription using Ollama API
def summarize_text_with_ollama(text):
    try:
        url = "http://localhost:11434/api/generate"
        payload = {"model": "llama3.1:8b", "prompt": f"Summarize the following text: {text}"}
        
        # Send a POST request with streaming enabled
        response = requests.post(url, json=payload, timeout=10, stream=True)
        response.raise_for_status()  # Check for request errors

        summary = ""
        for line in response.iter_lines(decode_unicode=True):
            if line:
                try:
                    response_data = json.loads(line)
                    if "response" in response_data:
                        summary += response_data["response"]
                        print(f"Partial summary: {summary}")  # Debug: log partial summary
                    if response_data.get("done", False):  # Check if the response is complete
                        break
                except ValueError as e:
                    print(f"Error parsing JSON: {e}")
                    return f"Error: Invalid response format from Ollama API."

        return summary.strip()

    except requests.exceptions.RequestException as e:
        print(f"Error summarizing text: {e}")
        return "Error summarizing text."

# Route to handle video file upload and processing
@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file part"}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400

        filename = secure_filename(file.filename)
        video_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(video_path)

        audio_path = os.path.join(app.config['UPLOAD_FOLDER'], 'audio.wav')
        extracted_audio = extract_audio(video_path, audio_path)

        if extracted_audio:
            transcription = transcribe_audio_with_vosk(extracted_audio)
            if not transcription:
                return jsonify({"error": "Transcription failed, no text found."}), 500

            summary = summarize_text_with_ollama(transcription)
            if not summary:
                return jsonify({"error": "Text summarization failed."}), 500

            return jsonify({
                'transcription': transcription,
                'summary': summary
            })
        else:
            return jsonify({"error": "Audio extraction failed"}), 500

    finally:
        # Clean up uploaded files
        if os.path.exists(video_path):
            os.remove(video_path)
        if os.path.exists(audio_path):
            os.remove(audio_path)

# Home route for the app
@app.route('/')
def home():
    return render_template('index3.html')

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
